#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface WebView : UIViewController

@end